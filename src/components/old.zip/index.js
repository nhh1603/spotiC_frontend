import Heart from './Heart'
import Play from './Play'
import Music from './Music'
import Music2 from './Music2'

import React from 'react'

export default function Components(props) {
    switch (props.name) {
        case 'Heart':
            return <Heart {...props}/>
        case 'Play':
            return <Play {...props}/>
        case 'Music':
            return <Music />
        case 'Music2':
            return <Music2 />          
        default:
            return null
    }
}
