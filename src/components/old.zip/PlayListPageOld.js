// import "../styles/PlaylistPage.css";
import React, {useEffect, useState, useContext, createContext, useRef, useCallback } from 'react'
import {useLocation} from 'react-router-dom'
import axios from 'axios'
import Components from '../components'
// import axiosRequest from '../components/axiosRequest'
// import useInfiScroll from '../components/useInfiScroll'

function PageBanner({pageTitle, bannerInfo}) {
    const {name, description, user, followers, primary_color, images, release_date, total} = bannerInfo
    let formattedLikes
    let imgUrl 
    if (images && images.length > 0){
        imgUrl = images[0].url
    }

    if (followers){
        formattedLikes = followers.total.toLocaleString('en-US')
    }
    return (
        <div className="banner" style={{backgroundColor:`${primary_color}`, height: pageTitle === 'artist'?'40vh':'30vh'}}>
            <div className={`bannerImgDiv ${pageTitle==='profile'||pageTitle==='artist'? 'circleDiv':null}`}>
                {imgUrl ? 
                    <img loading="lazy" src={imgUrl} className={`bannerImg ${pageTitle==='profile'||pageTitle==='artist'? 'circleDiv':null}`} alt="" />:
                    <div className="svgSizing">
                        <Components name='Music2'/>
                    </div>
                }
            </div>

            <div className="bannerInfo">
                <h2 className="pageTitle">{pageTitle}</h2>
                <span style={spanStyle}>
                    <h1 className={name.length > 15? "bannerTitleXL":"bannerTitle"}>{name}</h1>
                </span>
                <p className="bannerDescription" style={{display: description===''? 'none':'flex'}}>{description}</p>
                <div className="additionalInfo">
                    {user && user[0] && user.map((person, index) => (
                        <a key={index} href={`/${person.type}/${person.id}`}>{person.type === 'artist'? person.name:person.display_name}</a>
                    ))}
                    {total !== 0 && total&& 
                        <h2>{total} Playlists</h2>
                    }
                    {followers !== 0 &&
                        <h2 style={pageTitle === 'artist'? followerStyle:null}>{formattedLikes} {followerTitle(pageTitle)}</h2>
                    }
                    {release_date && 
                        <h2>{release_date}</h2>
                    }
                </div>
            </div>
            <div className="bannerOverlay"></div>
        </div>
    )
}


function followerTitle(title){
    switch (title) {
        case 'profile':
            return 'Followers'
        case 'artist':
            return 'monthly listeners'
        default:
            return 'Likes'
    }
}

const followerStyle ={
    fontSize: '16px',
    lineHeight: '2',
    marginTop: '4px',
    color: '#fff'
}

const spanStyle = {
    display: '-webkit-box',
    WebkitLineClamp: '3',
    WebkitBoxOrient: 'vertical',
    marginTop: '4px',
    wordBreak: 'break-word',
    overflow: 'hidden',
}

function axiosRequest(endpoint) {
    const controller = new AbortController();
    const { signal } = controller;
  
    const makeRequest = async () => {
      const config = {
        method: 'POST',
        url: process.env.REACT_APP_API_URL,
        data: { endpoint },
        withCredentials: false,
        signal,
      };
  
      try {
        const response = await axios(config);
        return response.data;
      } catch (error) {
        if (error.name === 'AbortError') {
          // if request cancelled, no action
          return;
        }
        // other errors
        return error;
      }
    };
  
    const cancelRequest = () => {
      controller.abort();
    };
  
    return [makeRequest, cancelRequest];
  }


function useInfiScroll(setList){
    const [next, setNext] = useState(null) 

    const observer = useRef()
    const lastRef = useCallback(node => {
        if (observer.current) observer.current.disconnect()
        observer.current = new IntersectionObserver(entries => {
            if(entries[0].isIntersecting && next){
                const [, makeRequest] = axiosRequest(next)
                makeRequest()
                    .then(data => {
                        let resultList, next
                        if (data.items && data.items[0].track){
                            resultList = data.items.map(track => track.track)
                        }else{
                            resultList = data.items || data.playlists.items
                        }

                        if (data.playlists){
                            next = data.playlists.next
                        }else{
                            next = data.next
                        }

                        setList(tracks => [...tracks, ...resultList])
                        setNext(next)
                    })
                    .catch(error => console.log(error))
            }
        }, {threshold: 0.75})
        if (node) observer.current.observe(node)
    // eslint-disable-next-line
    }, [next])

    return [setNext, lastRef]
}

// convert ms to min:sec
function msTimeFormat(ms){
    const s = Math.floor(ms/1000)
    const min = Math.floor(s /60) 
    const sec = (s - min*60) 

    return `${min}:${sec < 10? `0${sec}`: sec}` //1:01 instead of 1:1
}

// for share context
export const UserContext = createContext({})
export const LoginContext = createContext(false)
export const TokenContext = createContext(null)
export const MessageContext = createContext(() => {})
export const PlayContext = createContext(() => {})


// single item
const TrackListItem = React.forwardRef(
	({ track, styleName, highlight, playContextTrack }, ref) => {
		const { album, artists, name, explicit, duration_ms, uri } = track;
		const updatePlayer = useContext(PlayContext);

		let thumbNail;
		if (styleName === "simplify" && album.images.length > 0) {
			thumbNail = album.images[album.images.length - 1].url;
		}
		const formattedTime = msTimeFormat(duration_ms);
		return (
			<li
				ref={ref}
				className={`trackListItem ${highlight ? "highlight" : null}`}
			>
				<div
					className="trackItemPlay"
					style={styleName === "simplify" ? simplyStyle : null}
				>
					<button
						className={
							styleName === "simplify"
								? "hoverIcon no-outline"
								: "hoverIcon trackTopAlign no-outline"
						}
						onClick={() => {
							playContextTrack(uri);
							updatePlayer();
						}}
					>
						<Components name="Play" height="20" width="20" />
					</button>
					<div
						className={
							styleName === "simplify" ? "itemIcon" : "itemIcon trackTopAlign"
						}
						style={{ marginTop: styleName === "simplify" ? "0" : null }}
					>
						<Components name="Music" />
					</div>
				</div>

				{styleName === "simplify" && (
					<div className="trackMidAlign">
						<div className="trackItemThumb">
							{thumbNail ? (
								<img
									loading="lazy"
									src={thumbNail}
									style={{ width: "100%", height: "100%" }}
									alt=""
								/>
							) : (
								<div
									style={{
										position: "absolute",
										top: "35%",
										bottom: "35%",
										left: "35%",
										right: "35%",
									}}
								>
									<Components name="Music2" />
								</div>
							)}
						</div>
					</div>
				)}

				<div className="trackItemInfo">
					<div
						className={
							styleName === "simplify" ? "trackMidAlign" : "trackTopAlign"
						}
					>
						<div className="trackName ellipsis-one-line">{name}</div>

						{styleName !== "simplify" && (
							<div className="trackInfo">
								<span
									className="explicit-label"
									style={explicit ? { display: "flex" } : { display: "none" }}
								>
									E
								</span>
								<span className="trackArtists ellipsis-one-line">
									{artists.map((artist) => (
										<a href={`/artist/${artist.id}`} key={artist.id}>
											{artist.name}
										</a>
									))}
								</span>
								{album && (
									<>
										<span className="trackInfoSep">•</span>
										<span className="trackAlbum ellipsis-one-line">
											<a href={`/ablum/${album.id}`}>{album.name}</a>
										</span>
									</>
								)}
							</div>
						)}
					</div>
				</div>

				<div className="trackItemDuration">
					<div
						className={`duration ${
							styleName === "simplify" ? "trackMidAlign" : "trackTopAlign"
						}`}
					>
						<span>{formattedTime}</span>
					</div>
				</div>
			</li>
		);
	}
);

const simplyStyle = {
	display: "flex",
	alignItems: "center",
	justifyContent: "flex-end",
};

//
const TrackList = React.forwardRef(({tracks, styleName, highlight, playContextTrack}, ref) => {
    return (
        <div className="trackListContainer">
            <ol className="trackList">
                {tracks.map((track, index) => {
                    if (index+1 < tracks.length){
                        return <TrackListItem track={track} key={track.id} styleName={styleName} highlight={track.id === highlight} playContextTrack={playContextTrack}/>
                    }else{
                        return <TrackListItem ref={ref} track={track} key={track.id} styleName={styleName} highlight={track.id === highlight} playContextTrack={playContextTrack}/>
                    }
                })}
            </ol>
        </div>
    )
})

//
function PlayListFunctions({type, follow, onFollow, setMessage, playContext}) {
    const loggedIn = useContext(LoginContext)

    switch (type) {
        case 'playOnly':
            return (
                <div className="playListFunctions">
                    <PlayButtonLarge loggedIn={loggedIn} playContext={playContext}/>
                </div>
            )
        case 'none':
            return (
                <div className="playListFunctions">
                    <MoreButton onClick={() => setMessage('todo')}/>
                </div>
            )
        case 'user':
            return (
                <div className="playListFunctions">
                    <FollowButton follow={follow} onFollow={onFollow} loggedIn={loggedIn}/>
                    <MoreButton onClick={() => setMessage('todo')}/>
                </div>
                    
            )
        case 'artist':
            return (
                <div className="playListFunctions">
                    <PlayButtonLarge loggedIn={loggedIn} playContext={playContext}/>
                    <FollowButton follow={follow} onFollow={onFollow} loggedIn={loggedIn}/>
                    <MoreButton onClick={() => setMessage('todo')}/>
                </div>
            )
        default:
            return (
                <div className="playListFunctions">
                    <PlayButtonLarge loggedIn={loggedIn} playContext={playContext}/>
                    <LikeButton follow={follow} onFollow={onFollow} loggedIn={loggedIn}/>
                    <MoreButton onClick={() => setMessage('todo')}/>
                </div>
            )
    }
}

function PlayButtonLarge({loggedIn, playContext}){
    const updatePlayer = useContext(PlayContext)
    if (loggedIn){
        return (
            <button className="playButton no-outline" title="Play" onClick={() => {
                playContext()
                setTimeout(() => updatePlayer(), 500)
            }}>
                <Components name="Play" height='28' width='28'/>
            </button>
        )
    }else{
        return (
            <button className="playButton no-outline" title="Play" data-tip='play' data-for='tooltipMain' data-event='click' >
                <Components name="Play" height='28' width='28'/>
            </button>
        )
    }
    
}

function LikeButton({follow, onFollow, loggedIn}){
    if (loggedIn){
        return (
            <button className={`likeButton ${follow? 'noHover':''} no-outline`} style={{color: follow? 'var(--spotify-green)':null}} title={follow? 'Remove from Library':"Save to Your Library"} onClick={onFollow}>
                <Components name='Heart' fill={follow}/>
            </button>
        )
    }else{
        return (
            <button className="likeButton no-outline" title="Save to Your Library" data-tip='like' data-for='tooltipMain' data-event='click'>
                <Components name='Heart' fill={follow}/>
            </button>
        )
    }
}

function FollowButton({follow, onFollow, loggedIn}){
    if (loggedIn){
        return (
            <button className="followButton no-outline" onClick={onFollow}>{follow? 'following':'follow'}</button>
        )
    }else{
        return (
            <button className="followButton no-outline" data-tip='follow' data-for='tooltipMain' data-event='click' onClick={() => console.log('hi')}>{follow? 'following':'follow'}</button>
        )
    }
    
}

function MoreButton({onClick}){
    return (
        <button className="moreButton no-outline" title="More" onClick={onClick}>• • •</button>
    )
}

//
export default function PlayListPage({playlists, refreshPlaylist}) {
    // const id = useId('playlist')
    const id = 'playlist'
    // const loggedIn = useContext(LoginContext)
    const loggedIn = true;
    const token = useContext(TokenContext);
    const setMessage = useContext(MessageContext);
    const updatePlayer = useContext(PlayContext);
    const apiUrl = process.env.REACT_APP_API_URL;
    const location = useLocation();

    // const [loading, setLoading] = useState(true)

    const [bannerInfo, setbannerInfo] = useState({
        name: '',
        description: '',
        user: [],
        followers: 0,
        primary_color: '#262626',
        images: [],
    })
    const [tracks, setTracks] = useState([])
    const [like, setLike] = useState(false)
    const [setNext, lastRef] = useInfiScroll(setTracks)
    const [uri, setUri] = useState('')
    const queryParams = new URLSearchParams(location.search);
    const queryValue = queryParams.get("playlistId");
    // const source = axios.signal

    useEffect(() => {
        setLike(false)
        setUri('')
        setbannerInfo({
            name: '',
            description: '',
            user: [],
            followers: 0,
            primary_color: '#262626',
            images: [], 
        })
        setTracks([])
        // setLoading(true)

        const [playSource, makeRequest] = axiosRequest(apiUrl + `/playlist`)

        if (id){
            makeRequest()
            .then((data) => {
                const {name, description, owner, followers, primary_color, tracks, images, uri} = data
                // const {name, desc, user, songs, img, collaborative} = data
                
                setbannerInfo(bannerInfo => ({...bannerInfo, name, description, user:[owner], followers, primary_color, images}))
                setTracks(tracks.items.map((track) => track.track))
                setNext(tracks.next)
                setUri(uri)
                // setLoading(false)
            })
            .catch((error) => {
                // setLoading(false)
                setMessage(`ERROR: ${error}`)
            })
        }
        
        
        if (loggedIn && id){
            const playlistIds = playlists.map((playlist) => {
                return playlist.id
            })
            if (playlistIds.includes(id)){
                setLike(true)
            }
    }

    return () => {
        playSource.cancel()
        // source.cancel()
    }
    // eslint-disable-next-line
    }, [id, loggedIn])

    return (
        // loading? 
        // <Loading />
        // : 
        <div className='listPage' style={{display: `${tracks.length===0? 'none':'block'}`}}>
            <PageBanner pageTitle='playlist' bannerInfo={bannerInfo}/>
            <div className="playListContent">
                <div className="playListOverlay" style={{backgroundColor: "rgb(126, 70, 70)"}}></div>
                {/* <PlayListFunctions onFollow={true} follow={like} setMessage={setMessage} playContext={playContext}/> */}
                <PlayListFunctions onFollow={true} follow={like} setMessage={setMessage}/>
                <div className="page-content">
                    {/* <TrackList ref={lastRef} tracks={tracks} playContextTrack={playContextTrack}/> */}
                    <TrackList ref={lastRef} tracks={tracks}/>
                </div>
            </div>
        </div>
    )
}
