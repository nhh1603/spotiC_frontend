import axios from 'axios'

// https://axios-http.com/docs/cancellation
export default function axiosRequest(endpoint) {
  const controller = new AbortController();
  const { signal } = controller;

  const makeRequest = async () => {
    const config = {
      method: 'POST',
      url: process.env.REACT_APP_API_URL,
      data: { endpoint },
      withCredentials: true,
      signal,
    };

    try {
      const response = await axios(config);
      return response.data;
    } catch (error) {
      if (error.name === 'AbortError') {
        // if request cancelled, no action
        return;
      }
      // other errors
      return error;
    }
  };

  const cancelRequest = () => {
    controller.abort();
  };

  return [makeRequest, cancelRequest];
}

// export default function axiosRequest(endpoint) {
//     const controller = new AbortController();
//     const { signal } = controller;
  
//     const makeRequest = async () => {
//       const config = {
//         method: 'POST',
//         url: process.env.REACT_APP_API_URL,
//         data: { endpoint },
//         withCredentials: true,
//         signal,
//       };
  
//       try {
//         const response = await axios(config);
//         return response.data;
//       } catch (error) {
//         if (error.name === 'AbortError') {
//           // if request cancelled, no action
//           return;
//         }
//         // other errors
//         return error;
//       }
//     };
  
//     const cancelRequest = () => {
//       controller.abort();
//     };
  
//     return [makeRequest, cancelRequest];
//   }